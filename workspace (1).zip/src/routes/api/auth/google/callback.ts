import { createFileRoute } from "@tanstack/react-router"
import "@tanstack/react-start"
import { handleHappySeedsCallback } from "#/lib/happyseeds-platform-auth/server.ts"

/**
 * The callback path is fixed — HappySeeds redirects here after Google. Pass a
 * second argument to `handleHappySeedsCallback` to upsert a local user row by
 * OpenID when the app persists user-owned data.
 */
export const Route = createFileRoute("/api/auth/google/callback")({
  server: {
    handlers: {
      GET: ({ request }) => handleHappySeedsCallback(request),
    },
  },
})
