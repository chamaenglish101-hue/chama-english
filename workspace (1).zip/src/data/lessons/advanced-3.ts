import type { LessonContent } from "./types.ts"

export const ADVANCED_3: LessonContent[] = [
  {
    id: "a21",
    objective: "Usar os phrasal verbs do mundo dos negócios com naturalidade.",
    keyPoints: [
      "follow up = dar seguimento; reach out = entrar em contato.",
      "roll out = lançar, implantar; scale back = reduzir.",
      "break down = detalhar; wrap up = concluir.",
      "São separáveis ou não conforme o verbo: follow it up é possível; reach out to é inseparável.",
    ],
    explanation: [
      "Em reuniões corporativas, os phrasal verbs substituem o vocabulário latino e soam mais naturais: “reach out” em vez de “contact”, “roll out” em vez de “implement”.",
      "Domine dez e você já participa de qualquer reunião em inglês sem parecer formal demais.",
    ],
    examples: [
      { en: "I'll follow up with the client tomorrow.", pt: "Vou dar seguimento com o cliente amanhã." },
      { en: "We're rolling out the new system in May.", pt: "Vamos implantar o novo sistema em maio." },
      { en: "Let's wrap up the meeting with next steps.", pt: "Vamos encerrar a reunião com os próximos passos." },
    ],
    vocab: [
      { en: "to follow up", pt: "dar seguimento, cobrar retorno" },
      { en: "to reach out", pt: "entrar em contato" },
      { en: "to roll out", pt: "lançar, implantar" },
      { en: "to wrap up", pt: "encerrar, concluir" },
    ],
    practice: [
      {
        prompt: "O que significa “scale back the project”?",
        options: ["ampliar o projeto", "reduzir o projeto", "cancelar o projeto", "medir o projeto"],
        answer: 1,
        explanation: "scale back = reduzir escopo, tamanho ou investimento.",
      },
      {
        prompt: "Complete: “I'll ___ out to the team about the deadline.”",
        options: ["reach", "roll", "wrap", "break"],
        answer: 0,
        explanation: "reach out to someone = entrar em contato com alguém.",
      },
    ],
    takeaway: "Você soa natural em reuniões e e-mails de trabalho.",
    tip: "Escolha cinco phrasal verbs de negócios e use cada um em uma frase sobre sua rotina profissional.",
  },
  {
    id: "a22",
    objective: "Descrever relações pessoais e conflitos com os phrasal verbs certos.",
    keyPoints: [
      "get along (with) = se dar bem; fall out = brigar, romper.",
      "make up = fazer as pazes; look up to = admirar.",
      "grow apart = se afastar aos poucos; put up with = tolerar.",
      "ask out = convidar para sair; break up = terminar o relacionamento.",
    ],
    explanation: [
      "Esses verbos descrevem a vida afetiva com precisão que o vocabulário formal não alcança: “we grew apart” conta uma história inteira em três palavras.",
      "Como sempre, aprenda em contexto: pense em uma relação real para cada expressão.",
    ],
    examples: [
      { en: "I get along really well with my in-laws.", pt: "Me dou muito bem com meus sogros." },
      { en: "They fell out over money and never made up.", pt: "Eles brigaram por dinheiro e nunca fizeram as pazes." },
      { en: "I look up to my older sister.", pt: "Admiro minha irmã mais velha." },
    ],
    vocab: [
      { en: "to get along with", pt: "se dar bem com" },
      { en: "to fall out with", pt: "brigar com" },
      { en: "to make up", pt: "fazer as pazes" },
      { en: "to grow apart", pt: "se afastar aos poucos" },
    ],
    practice: [
      {
        prompt: "O que significa “they grew apart”?",
        options: [
          "eles se aproximaram",
          "eles se afastaram com o tempo",
          "eles se mudaram",
          "eles brigaram de repente",
        ],
        answer: 1,
        explanation: "grew apart é o afastamento gradual, sem briga declarada.",
      },
      {
        prompt: "Complete: “I can't ___ up with this noise any longer.”",
        options: ["put", "make", "get", "look"],
        answer: 0,
        explanation: "put up with = tolerar, suportar.",
      },
    ],
    takeaway: "Você fala de relações com nuance e naturalidade.",
    tip: "Descreva três relações da sua vida usando get along, look up to e grow apart.",
  },
  {
    id: "a23",
    objective: "Entender phrasal verbs de múltiplos sentidos pelo contexto.",
    keyPoints: [
      "take off: decolar / tirar roupa / fazer sucesso.",
      "run out of: acabar o estoque; run into: encontrar por acaso.",
      "put down: criticar / anotar / sacrificar (animais).",
      "O sentido depende do objeto e do contexto — nunca da partícula isolada.",
    ],
    explanation: [
      "Phrasal verbs polissêmicos são a razão pela qual decorar listas não basta. É o contexto que define: “the plane took off” não é o mesmo que “the brand took off”.",
      "A estratégia é treinar flexibilidade: ao encontrar um sentido novo, registre a frase inteira, não só o verbo.",
    ],
    examples: [
      { en: "The flight took off on time.", pt: "O voo decolou no horário." },
      { en: "Her channel took off after that video.", pt: "O canal dela decolou depois daquele vídeo." },
      { en: "We ran out of coffee this morning.", pt: "Acabou o café esta manhã." },
    ],
    vocab: [
      { en: "to take off", pt: "decolar / tirar (roupa) / deslanchar" },
      { en: "to run out of", pt: "ficar sem" },
      { en: "to run into", pt: "encontrar por acaso" },
      { en: "to put down", pt: "criticar / anotar / baixar" },
    ],
    practice: [
      {
        prompt: "Em “the company took off”, o sentido é:",
        options: ["decolou um avião", "tirou a roupa", "deslanchou, cresceu rápido", "fechou"],
        answer: 2,
        explanation: "Aplicado a negócios ou projetos, take off significa deslanchar.",
      },
      {
        prompt: "Complete: “I ___ into my old teacher at the airport.”",
        options: ["ran", "took", "put", "made"],
        answer: 0,
        explanation: "run into someone = encontrar alguém por acaso.",
      },
    ],
    takeaway: "Você interpreta phrasal verbs pelo contexto, não por decoreba.",
    tip: "Escolha um phrasal verb polissêmico e escreva três frases, cada uma com um sentido diferente.",
  },
  {
    id: "a24",
    objective: "Usar expressões idiomáticas frequentes em contexto de conversa real.",
    keyPoints: [
      "to be swamped = estar sobrecarregado de trabalho.",
      "to get the hang of it = pegar o jeito.",
      "to be on the fence = estar indeciso.",
      "to bite the bullet = encarar uma decisão difícil.",
    ],
    explanation: [
      "Idioms de uso frequente aparecem em qualquer conversa informal de trabalho. Eles carregam tom e humor que o vocabulário neutro não tem.",
      "Aprenda cinco de cada vez e use-os na semana: só entra no vocabulário ativo o que você pratica.",
    ],
    examples: [
      { en: "I'm swamped this week, can we talk on Friday?", pt: "Estou atolado esta semana, podemos falar na sexta?" },
      { en: "It took a while, but I got the hang of it.", pt: "Levou um tempo, mas peguei o jeito." },
      { en: "Let's just bite the bullet and hire more people.", pt: "Vamos encarar e contratar mais gente." },
    ],
    vocab: [
      { en: "to be swamped", pt: "estar atolado de trabalho" },
      { en: "to get the hang of it", pt: "pegar o jeito" },
      { en: "to be on the fence", pt: "estar indeciso" },
      { en: "to bite the bullet", pt: "encarar, tomar a decisão difícil" },
    ],
    practice: [
      {
        prompt: "Seu colega diz “I'm swamped”. Ele está:",
        options: ["de férias", "sobrecarregado", "doente", "animado"],
        answer: 1,
        explanation: "swamped significa atolado, com muito trabalho.",
      },
      {
        prompt: "Complete: “It was hard at first, but I'm getting the ___ of it.”",
        options: ["hand", "hang", "head", "hook"],
        answer: 1,
        explanation: "A expressão é get the hang of it — pegar o jeito.",
      },
    ],
    takeaway: "Você soa espontâneo em conversas informais de trabalho.",
    tip: "Use três idioms desta lição em mensagens reais nesta semana.",
  },
  {
    id: "a25",
    objective: "Ampliar o repertório com idioms mais elaborados e sua carga cultural.",
    keyPoints: [
      "to go the extra mile = fazer além do esperado.",
      "to be in the dark = não estar informado.",
      "to rock the boat = criar problema em uma situação estável.",
      "to cut corners = fazer às pressas, economizando o que não deve.",
    ],
    explanation: [
      "Esses idioms têm carga avaliativa: indicam aprovação ou crítica. Usá-los bem exige perceber o julgamento embutido.",
      "Em contexto profissional, “cut corners” é uma acusação séria, enquanto “go the extra mile” é elogio.",
    ],
    examples: [
      { en: "She always goes the extra mile for clients.", pt: "Ela sempre faz além do esperado pelos clientes." },
      { en: "We were kept in the dark about the changes.", pt: "Fomos deixados no escuro sobre as mudanças." },
      { en: "Don't cut corners on testing.", pt: "Não economize no que não deve, especialmente em testes." },
    ],
    vocab: [
      { en: "to go the extra mile", pt: "fazer além do esperado" },
      { en: "to be in the dark", pt: "não estar informado" },
      { en: "to rock the boat", pt: "criar problema" },
      { en: "to cut corners", pt: "fazer de qualquer jeito para economizar" },
    ],
    practice: [
      {
        prompt: "“They cut corners on safety” significa:",
        options: [
          "investiram mais em segurança",
          "economizaram de forma irresponsável na segurança",
          "melhoraram a segurança",
          "não falaram de segurança",
        ],
        answer: 1,
        explanation: "cut corners é economizar de forma irresponsável, com crítica implícita.",
      },
      {
        prompt: "Complete: “I don't want to ___ the boat, but I disagree.”",
        options: ["rock", "roll", "shake", "break"],
        answer: 0,
        explanation: "rock the boat = criar problema em uma situação estabilizada.",
      },
    ],
    takeaway: "Você usa idioms com o julgamento adequado ao contexto.",
    tip: "Escolha dois idioms avaliativos e escreva um comentário de avaliação profissional com cada um.",
  },
  {
    id: "a26",
    objective: "Falar como o escritório fala, com idioms do mundo do trabalho.",
    keyPoints: [
      "get the ball rolling = começar, dar o pontapé inicial.",
      "touch base = dar uma passada, alinhar rapidamente.",
      "on the same page = alinhado; in the loop = ciente.",
      "back to the drawing board = recomeçar do zero.",
    ],
    explanation: [
      "Esses idioms surgem em reuniões e mensagens de trabalho o tempo todo. Conhecê-los evita mal-entendidos e deixa sua fala mais natural.",
      "“Touch base” e “circle back” são especialmente úteis quando você quer propor uma conversa rápida sem marcar reunião formal.",
    ],
    examples: [
      { en: "Let's get the ball rolling with a kickoff meeting.", pt: "Vamos dar o pontapé inicial com uma reunião de abertura." },
      { en: "I'll touch base with you on Thursday.", pt: "Falo com você rapidamente na quinta." },
      { en: "Keep me in the loop, please.", pt: "Me mantenha informado, por favor." },
    ],
    vocab: [
      { en: "to get the ball rolling", pt: "começar, dar o pontapé inicial" },
      { en: "to touch base", pt: "alinhar rapidamente" },
      { en: "in the loop", pt: "informado, ciente" },
      { en: "back to the drawing board", pt: "recomeçar do zero" },
    ],
    practice: [
      {
        prompt: "O que significa “touch base with someone”?",
        options: [
          "demitir alguém",
          "falar rapidamente para alinhar",
          "elogiar alguém",
          "mudar de equipe",
        ],
        answer: 1,
        explanation: "touch base é um contato rápido para alinhar informações.",
      },
      {
        prompt: "Complete: “Please keep me ___ the loop about the changes.”",
        options: ["on", "in", "at", "with"],
        answer: 1,
        explanation: "A expressão fixa é keep someone in the loop.",
      },
    ],
    takeaway: "Você participa de reuniões em inglês sem perder as entrelinhas.",
    tip: "Escreva uma mensagem curta de trabalho usando touch base e keep in the loop.",
  },
  {
    id: "a27",
    objective: "Usar collocations de alto nível e evitar o português traduzido.",
    keyPoints: [
      "to draw a conclusion, to raise concerns, to meet a deadline.",
      "to take responsibility, to play a key role, to pose a risk.",
      "to gain experience, to make progress, to reach an agreement.",
      "Substantivos abstratos costumam vir com verbos específicos — memorize os pares.",
    ],
    explanation: [
      "Em nível avançado o desafio não é a gramática, mas a parceria entre as palavras. “Do a conclusion” está gramaticalmente correto e ainda assim soa errado.",
      "A boa notícia: essas combinações se repetem. Anote sempre o par completo, nunca só o substantivo.",
    ],
    examples: [
      { en: "We need to raise this concern with the client.", pt: "Precisamos levantar essa preocupação com o cliente." },
      { en: "She played a key role in the project.", pt: "Ela teve um papel fundamental no projeto." },
      { en: "We finally reached an agreement.", pt: "Finalmente chegamos a um acordo." },
    ],
    vocab: [
      { en: "to raise concerns", pt: "levantar preocupações" },
      { en: "to meet a deadline", pt: "cumprir um prazo" },
      { en: "to play a key role", pt: "ter um papel fundamental" },
      { en: "to reach an agreement", pt: "chegar a um acordo" },
    ],
    practice: [
      {
        prompt: "Qual combinação está correta?",
        options: ["do a conclusion", "draw a conclusion", "make a conclusion", "take a conclusion"],
        answer: 1,
        explanation: "A combinação natural é draw a conclusion.",
      },
      {
        prompt: "Complete: “The team ___ a key role in the launch.”",
        options: ["did", "played", "made", "took"],
        answer: 1,
        explanation: "play a key role é a collocation correta.",
      },
    ],
    takeaway: "Você escreve sem o sotaque do português traduzido.",
    tip: "Anote cinco collocations novas por dia junto com a frase inteira em que apareceram.",
  },
  {
    id: "a28",
    objective: "Escolher entre registro formal, neutro e informal conforme o leitor.",
    keyPoints: [
      "Formal: I would like to request… / We regret to inform you…",
      "Neutro: I'd like to ask… / Just to let you know…",
      "Informal: Hey, quick question… / Any thoughts?",
      "O mesmo conteúdo muda de roupa: comece escolhendo o registro.",
    ],
    explanation: [
      "Registro é adequação, não correção. Um texto formal demais em um chat soa frio; um texto informal em uma proposta comercial soa amador.",
      "Ajuste três coisas: contrações, vocabulário e estrutura de frase. Formas longas e completas para formal; contrações e frases curtas para informal.",
    ],
    examples: [
      { en: "I would like to request an extension of the deadline.", pt: "Gostaria de solicitar uma prorrogação do prazo." },
      { en: "Could I have a few more days?", pt: "Poderia ter mais alguns dias?" },
      { en: "Hey, any chance we get a couple more days?", pt: "Oi, tem chance de conseguirmos mais uns dias?" },
    ],
    vocab: [
      { en: "to request / to ask", pt: "solicitar / pedir" },
      { en: "we regret to inform you", pt: "lamentamos informar" },
      { en: "just to let you know", pt: "só para você saber" },
      { en: "quick question", pt: "pergunta rápida" },
    ],
    practice: [
      {
        prompt: "Qual frase serve para uma proposta comercial formal?",
        options: [
          "Hey, wanna work together?",
          "We would like to propose a partnership.",
          "Let's do business, ok?",
          "Hey, quick one: partnership?",
        ],
        answer: 1,
        explanation: "“We would like to propose…” mantém o registro formal adequado.",
      },
      {
        prompt: "Você precisa de mais prazo em um chat com o time. Qual opção soa natural?",
        options: [
          "I would like to request an extension of the deadline.",
          "Hey, any chance we get a couple more days?",
          "We regret to inform you of a delay.",
          "Pursuant to our agreement, an extension is required.",
        ],
        answer: 1,
        explanation: "No chat interno, frases curtas e contrações soam naturais e mantêm a boa convivência.",
      },
    ],
    takeaway: "Você ajusta o tom em um segundo, para qualquer leitor.",
    tip: "Pegue um pedido seu e escreva as três versões: formal, neutra e informal.",
  },
  {
    id: "a29",
    objective: "Estruturar e-mails profissionais longos com clareza e diplomacia.",
    keyPoints: [
      "Assunto específico: “Proposal: Q3 marketing plan — feedback by Friday”.",
      "Primeiro parágrafo: contexto e objetivo em duas frases.",
      "Corpo: tópicos numerados ou bullet points, um assunto por bloco.",
      "Fechamento: ação esperada, prazo e disponibilidade para dúvidas.",
    ],
    explanation: [
      "E-mails longos precisam de arquitetura. Quem lê deve encontrar a informação sem reler o texto: assunto claro, resumo inicial e blocos curtos.",
      "Diplomacia entra nas formas de pedido e nas concessões: “I understand the constraint; however…”.",
    ],
    examples: [
      { en: "I'm writing to follow up on our conversation about the budget.", pt: "Escrevo para dar seguimento à nossa conversa sobre o orçamento." },
      { en: "For clarity, I've listed the three options below.", pt: "Para maior clareza, listei as três opções abaixo." },
      { en: "Could you confirm by Thursday so we can proceed?", pt: "Você poderia confirmar até quinta para prosseguirmos?" },
    ],
    vocab: [
      { en: "to follow up on", pt: "dar seguimento a" },
      { en: "for clarity", pt: "para maior clareza" },
      { en: "to proceed", pt: "prosseguir" },
      { en: "at your earliest convenience", pt: "o quanto antes possível" },
    ],
    practice: [
      {
        prompt: "Qual assunto de e-mail é mais eficiente?",
        options: [
          "Important!!!",
          "Proposal: Q3 marketing plan — feedback by Friday",
          "Regarding some things",
          "Hello",
        ],
        answer: 1,
        explanation:
          "Assunto específico com tema e prazo permite decidir a prioridade sem abrir o e-mail.",
      },
      {
        prompt: "Como fechar pedindo ação com prazo?",
        options: [
          "Could you confirm by Thursday so we can proceed?",
          "Answer me soon.",
          "I need an answer, please.",
          "Please reply, it's urgent!!!",
        ],
        answer: 0,
        explanation: "Pedido educado com prazo e consequência facilita a resposta.",
      },
    ],
    takeaway: "Você escreve e-mails longos que as pessoas leem e respondem.",
    tip: "Reescreva um e-mail longo seu aplicando assunto específico, resumo inicial e blocos numerados.",
  },
  {
    id: "a30",
    objective: "Escrever reclamações formais e cartas de resolução.",
    keyPoints: [
      "Estrutura: fato, evidências, impacto, pedido e prazo.",
      "Tom firme e educado: I must express my disappointment with…",
      "Peça algo concreto: a replacement, a refund, a written explanation.",
      "Na carta de resolução: reconheça, explique, ofereça e agradeça.",
    ],
    explanation: [
      "A reclamação formal difere da conversa cotidiana pelo registro e pela organização. Cada parágrafo cumpre uma função e o pedido é explícito.",
      "A carta de resolução tem o caminho inverso: assumir, explicar sem justificar demais, oferecer compensação e recuperar a relação.",
    ],
    examples: [
      { en: "I must express my disappointment with the service provided.", pt: "Preciso expressar minha decepção com o serviço prestado." },
      { en: "I expect a full refund within ten business days.", pt: "Espero o reembolso integral em dez dias úteis." },
      { en: "We sincerely apologize for the inconvenience and have processed your refund.", pt: "Pedimos sinceras desculpas pelo transtorno e processamos seu reembolso." },
    ],
    vocab: [
      { en: "to express disappointment", pt: "expressar decepção" },
      { en: "to expect / to require", pt: "esperar / exigir" },
      { en: "inconvenience", pt: "transtorno" },
      { en: "to process a refund", pt: "processar um reembolso" },
    ],
    practice: [
      {
        prompt: "Qual é o tom adequado em uma reclamação formal?",
        options: [
          "This is unacceptable and you are all useless.",
          "I must express my disappointment with the service provided.",
          "You people never do anything right.",
          "I want my money back right now!!!",
        ],
        answer: 1,
        explanation:
          "Firmeza formal se constrói com estrutura e vocabulário, não com ataques ou exclamações.",
      },
      {
        prompt: "Qual elemento não pode faltar na carta de resolução?",
        options: [
          "Uma oferta concreta de solução",
          "Justificativas longas",
          "Culpabilizar o cliente",
          "Silêncio sobre o problema",
        ],
        answer: 0,
        explanation: "Sem uma solução concreta, a carta não resolve nada.",
      },
    ],
    takeaway: "Você resolve conflitos por escrito com firmeza e elegância.",
    tip: "Escreva uma reclamação formal de cinco parágrafos e depois a resposta da empresa.",
  },
]
