import type { LessonPracticeContent } from "#/lib/exercises.ts"

/** Plural dos substantivos — 12 perguntas. */
export const B07_PRACTICE: LessonPracticeContent = {
  id: "b07",
  level: "iniciante",
  exercises: [
    {
      kind: "completar",
      prompt: "The ___ are playing with the dogs.",
      hint: "As crianças estão brincando com os cachorros.",
      options: ["children", "childs", "childrens", "child"],
      answer: 0,
      explanation:
        "“Child” tem plural irregular: children. “Childs” não existe em inglês.",
    },
    {
      kind: "completar",
      prompt: "I need some ___ about the courses.",
      hint: "Preciso de algumas informações sobre os cursos.",
      options: ["information", "informations", "an information", "informing"],
      answer: 0,
      explanation:
        "“Information” é incontável e fica no singular: para contar, diga “a piece of information”.",
    },
    {
      kind: "traduzir",
      prompt: "Dois ônibus e três táxis estão esperando.",
      bank: ["Two", "buses", "and", "three", "taxis", "are", "waiting", "is"],
      answer: ["Two", "buses", "and", "three", "taxis", "are", "waiting"],
      explanation:
        "“Bus” termina em “s” e faz plural com “es”: buses. “Taxi” só acrescenta “s”.",
    },
    {
      kind: "traduzir",
      prompt: "Há muitas pessoas na rua.",
      bank: ["There", "are", "many", "people", "on", "the", "street", "is"],
      answer: ["There", "are", "many", "people", "on", "the", "street"],
      explanation:
        "“People” já é plural: nunca “peoples”. O verbo acompanha no plural: “there are”.",
    },
    {
      kind: "falar",
      prompt: "Two buses and three taxis are waiting.",
      pt: "Dois ônibus e três táxis estão esperando.",
      tip: "Em “buses” o plural tem som de “iz”: “BÁ-siz”. Sem esse pedacinho, vira “bus” no singular.",
    },
    {
      kind: "falar",
      prompt: "The children are playing with the dogs.",
      pt: "As crianças estão brincando com os cachorros.",
      tip: "“Children” tem dois sons: “TCHIL-dren”. O “ch” é igual ao nosso “tch”.",
    },
    {
      kind: "imagem",
      prompt: "There are three cats on the sofa.",
      pt: "Há três gatos no sofá.",
      options: [
        {
          caption: "There are three cats on the sofa.",
          photo: "three cats sitting on a sofa",
          src: "",
          credit: "",
        },
        {
          caption: "There are two dogs on the bed.",
          photo: "two dogs lying on a bed",
          src: "",
          credit: "",
        },
        {
          caption: "There is one cat on the chair.",
          photo: "one cat sitting on a chair",
          src: "",
          credit: "",
        },
        {
          caption: "There are four kittens in a basket.",
          photo: "four kittens sleeping in a basket",
          src: "",
          credit: "",
        },
      ],
      answer: 0,
      explanation:
        "Conte os animais e olhe o móvel: são três gatos no sofá, não dois cães nem quatro filhotes.",
    },
    {
      kind: "imagem",
      prompt: "The children are brushing their teeth.",
      pt: "As crianças estão escovando os dentes.",
      options: [
        {
          caption: "The children are brushing their teeth.",
          photo: "two children brushing their teeth in a bathroom",
          src: "",
          credit: "",
        },
        {
          caption: "The children are washing their hands.",
          photo: "two children washing their hands at a sink",
          src: "",
          credit: "",
        },
        {
          caption: "The children are having a bath.",
          photo: "children playing in a bathtub",
          src: "",
          credit: "",
        },
        {
          caption: "The children are combing their hair.",
          photo: "children combing their hair in a mirror",
          src: "",
          credit: "",
        },
      ],
      answer: 0,
      explanation:
        "Escova de dentes e espuma na boca: o plural irregular “teeth” aparece na cena certa.",
    },
    {
      kind: "ouvirPalavra",
      audio: "children",
      options: ["crianças", "homens", "mulheres", "pessoas"],
      answer: 0,
      explanation:
        "“Children” é o plural de child. Nunca diga “childs” — é uma das poucas formas irregulares do inglês.",
    },
    {
      kind: "ouvirPalavra",
      audio: "teeth",
      options: ["dentes", "pés", "mãos", "olhos"],
      answer: 0,
      explanation:
        "“Teeth” é o plural de tooth. Para um dente só, a palavra é “tooth”.",
    },
    {
      kind: "ouvirFrase",
      audio: "Two buses and three taxis are waiting.",
      pt: "Dois ônibus e três táxis estão esperando.",
      options: [
        "Two buses and three taxis are waiting.",
        "Two buses and three taxis is waiting.",
        "Two cars and three taxis are waiting.",
        "Two buses and three drivers are waiting.",
      ],
      answer: 0,
      explanation:
        "Ouça “buses” com o plural em “iz” e o verbo “are”, que combina com dois sujeitos no plural.",
    },
    {
      kind: "ouvirFrase",
      audio: "I need some information about the courses.",
      pt: "Preciso de algumas informações sobre os cursos.",
      options: [
        "I need some information about the courses.",
        "I need some informations about the courses.",
        "I need some information about the classes.",
        "I need a information about the courses.",
      ],
      answer: 0,
      explanation:
        "Só uma frase está correta: “information” nunca vai para o plural em inglês.",
    },
  ],
}
