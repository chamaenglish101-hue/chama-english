/**
 * The twelve practice questions of each lesson, looked up by lesson id.
 *
 * Lessons are written in blocks, so this index grows as content lands: a lesson
 * without questions yet simply returns nothing, and its page offers the reading
 * material instead of an empty drill. Nothing has to be edited to publish a new
 * block except adding its file here.
 */

import { B01_PRACTICE } from "#/data/practice/b01.ts"
import { B02_PRACTICE } from "#/data/practice/b02.ts"
import { B03_PRACTICE } from "#/data/practice/b03.ts"
import { B04_PRACTICE } from "#/data/practice/b04.ts"
import { B05_PRACTICE } from "#/data/practice/b05.ts"
import { B06_PRACTICE } from "#/data/practice/b06.ts"
import { B07_PRACTICE } from "#/data/practice/b07.ts"
import { B08_PRACTICE } from "#/data/practice/b08.ts"
import { B09_PRACTICE } from "#/data/practice/b09.ts"
import { B10_PRACTICE } from "#/data/practice/b10.ts"
import { B11_PRACTICE } from "#/data/practice/b11.ts"
import { B12_PRACTICE } from "#/data/practice/b12.ts"
import { B13_PRACTICE } from "#/data/practice/b13.ts"
import { B14_PRACTICE } from "#/data/practice/b14.ts"
import type { LessonPracticeContent } from "#/lib/exercises.ts"
import { resolveExerciseImages } from "#/lib/lesson-images.ts"

/** Lessons whose twelve questions are published. */
export const PRACTICE_LESSONS: LessonPracticeContent[] = [
  B01_PRACTICE,
  B02_PRACTICE,
  B03_PRACTICE,
  B04_PRACTICE,
  B05_PRACTICE,
  B06_PRACTICE,
  B07_PRACTICE,
  B08_PRACTICE,
  B09_PRACTICE,
  B10_PRACTICE,
  B11_PRACTICE,
  B12_PRACTICE,
  B13_PRACTICE,
  B14_PRACTICE,
]

const BY_ID = new Map(PRACTICE_LESSONS.map((lesson) => [lesson.id, lesson]))

/**
 * Questions of one lesson, copied and ready to render.
 *
 * The copy matters: the picture files and credits are filled in here, and a stored
 * copy means one lesson's exercise list is never mutated while another learner reads
 * it. Pictures are resolved on every call so a newly published photo appears without
 * a rebuild.
 */
export function practiceFor(lessonId: string): LessonPracticeContent | null {
  const source = BY_ID.get(lessonId)
  if (!source) return null
  const copy = structuredClone(source)
  resolveExerciseImages(copy.exercises)
  return copy
}

/** Whether a lesson already has its twelve questions. */
export function hasPractice(lessonId: string): boolean {
  return BY_ID.has(lessonId)
}

/** Ids of the lessons with questions, for progress messages and dashboards. */
export function publishedLessonIds(): string[] {
  return PRACTICE_LESSONS.map((lesson) => lesson.id)
}
