import type { LessonPracticeContent } from "#/lib/exercises.ts"

/** Pronomes: I, my, you, your — 12 perguntas. */
export const B05_PRACTICE: LessonPracticeContent = {
  id: "b05",
  level: "iniciante",
  exercises: [
    {
      kind: "completar",
      prompt: "This is my brother and ___ wife.",
      hint: "Este é meu irmão e a esposa dele.",
      options: ["his", "her", "their", "its"],
      answer: 0,
      explanation:
        "O irmão é ele: “his wife”. “Her” seria dela, e “their” fala de mais de uma pessoa.",
    },
    {
      kind: "completar",
      prompt: "Her name is Juliana and ___ dog is called Bidu.",
      hint: "O nome dela é Juliana e o cachorro deles se chama Bidu.",
      options: ["their", "his", "her", "our"],
      answer: 0,
      explanation:
        "O cachorro é de Juliana e do irmão — duas pessoas, então “their”. “Our” incluiria você na família.",
    },
    {
      kind: "traduzir",
      prompt: "Esta é a minha casa.",
      bank: ["This", "is", "my", "house", "your", "his"],
      answer: ["This", "is", "my", "house"],
      explanation:
        "“My” acompanha o substantivo: “my house”. “Mine” aparece sozinho, sem o substantivo depois.",
    },
    {
      kind: "traduzir",
      prompt: "Nós amamos a nossa cidade.",
      bank: ["We", "love", "our", "city", "their", "my"],
      answer: ["We", "love", "our", "city"],
      explanation:
        "“Our” é nosso, para o grupo que inclui quem fala. “Their” seria deles.",
    },
    {
      kind: "falar",
      prompt: "This is my brother and his wife.",
      pt: "Este é meu irmão e a esposa dele.",
      tip: "O “th” de this é com a língua entre os dentes. Sem esse detalhe, vira “dis”.",
    },
    {
      kind: "falar",
      prompt: "We love our city.",
      pt: "Nós amamos a nossa cidade.",
      tip: "Ligue “love our” como “ló-vaur”: o “our” soa fraco, quase “ar”.",
    },
    {
      kind: "imagem",
      prompt: "She is with her parents at the park.",
      pt: "Ela está com os pais dela no parque.",
      options: [
        {
          caption: "She is with her parents at the park.",
          photo: "young woman walking with her parents in a park",
          src: "",
          credit: "",
        },
        {
          caption: "She is with her friends at a concert.",
          photo: "young woman with friends at a concert",
          src: "",
          credit: "",
        },
        {
          caption: "She is having lunch with her boss.",
          photo: "woman having lunch with her boss",
          src: "",
          credit: "",
        },
        {
          caption: "She is playing with her dog at home.",
          photo: "woman playing with her dog at home",
          src: "",
          credit: "",
        },
      ],
      answer: 0,
      explanation:
        "Pais mais velhos, conversa calma e verde ao fundo: um passeio em família, não uma festa.",
    },
    {
      kind: "imagem",
      prompt: "He is showing his new apartment to a friend.",
      pt: "Ele está mostrando o apartamento novo dele para um amigo.",
      options: [
        {
          caption: "He is showing his new apartment to a friend.",
          photo: "man showing an empty apartment to a visitor",
          src: "",
          credit: "",
        },
        {
          caption: "He is packing boxes to move out.",
          photo: "man packing cardboard boxes to move",
          src: "",
          credit: "",
        },
        {
          caption: "He is fixing the sink in the kitchen.",
          photo: "man fixing the sink in a kitchen",
          src: "",
          credit: "",
        },
        {
          caption: "He is watering the plants on the balcony.",
          photo: "man watering plants on a balcony",
          src: "",
          credit: "",
        },
      ],
      answer: 0,
      explanation:
        "O apartamento vazio e o gesto de apresentar o espaço dizem que ele está mostrando, não arrumando.",
    },
    {
      kind: "ouvirPalavra",
      audio: "our",
      options: ["nosso", "deles", "dela", "seu"],
      answer: 0,
      explanation:
        "“Our” é nosso, quando quem fala está incluído. “Your” é seu, de quem ouve — som parecido, sentido diferente.",
    },
    {
      kind: "ouvirPalavra",
      audio: "their",
      options: ["deles", "nosso", "meu", "dela"],
      answer: 0,
      explanation:
        "“Their” é deles. Cuidado: “there” (lá) e “they're” (eles estão) soam igual, mas escrevem-se diferente.",
    },
    {
      kind: "ouvirFrase",
      audio: "This is my brother and his wife.",
      pt: "Este é meu irmão e a esposa dele.",
      options: [
        "This is my brother and his wife.",
        "This is my brother and her wife.",
        "This is her brother and my wife.",
        "These are my brothers and their wives.",
      ],
      answer: 0,
      explanation:
        "Duas pistas: “my brother” no singular e “his”, porque o irmão é ele.",
    },
    {
      kind: "ouvirFrase",
      audio: "We love our city.",
      pt: "Nós amamos a nossa cidade.",
      options: [
        "We love our city.",
        "We love your city.",
        "They love their city.",
        "We leave our city.",
      ],
      answer: 0,
      explanation:
        "Ouça o começo “we” e depois “our”. “Your” tiraria você do grupo; “leave” seria ir embora.",
    },
  ],
}
