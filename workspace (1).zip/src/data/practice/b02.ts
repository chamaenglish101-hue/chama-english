import type { LessonPracticeContent } from "#/lib/exercises.ts"

/** Cumprimentos e despedidas — 12 perguntas. */
export const B02_PRACTICE: LessonPracticeContent = {
  id: "b02",
  level: "iniciante",
  exercises: [
    {
      kind: "completar",
      prompt: "___ morning! How are you today?",
      hint: "Bom dia! Como você está hoje?",
      options: ["Good", "Nice", "Fine", "Well"],
      answer: 0,
      explanation:
        "O cumprimento completo é “Good morning”. “Nice” pede “to meet you” e “Fine” responde como você está — não abre a saudação.",
    },
    {
      kind: "completar",
      prompt: "See you ___. Good night!",
      hint: "Até amanhã. Boa noite!",
      options: ["tomorrow", "yesterday", "today", "now"],
      answer: 0,
      explanation:
        "“See you tomorrow” marca um encontro no dia seguinte. “See you yesterday” seria voltar no tempo — impossível.",
    },
    {
      kind: "traduzir",
      prompt: "Boa tarde, senhora Silva.",
      bank: ["Good", "afternoon", "Mrs.", "Silva", "night", "morning"],
      answer: ["Good", "afternoon", "Mrs.", "Silva"],
      explanation:
        "“Good afternoon” vale do meio-dia até o fim da tarde. Depois disso, o cumprimento passa a ser “good evening”.",
    },
    {
      kind: "traduzir",
      prompt: "Tchau, até logo!",
      bank: ["Bye", "see", "you", "later", "good", "morning"],
      answer: ["Bye", "see", "you", "later"],
      explanation:
        "“See you later” é o “até logo” do dia a dia. Note o “you” no meio: nunca “see later you”.",
    },
    {
      kind: "falar",
      prompt: "Good morning! How are you today?",
      pt: "Bom dia! Como você está hoje?",
      tip: "Atenção ao “H” de how: é soprado, como um sopro leve. Sem isso, “how” soa como “ow”.",
    },
    {
      kind: "falar",
      prompt: "Hi, Ana! Nice to see you again.",
      pt: "Oi, Ana! Que bom te ver de novo.",
      tip: "Ligue “Nice to” como “naiss-tu”: a vogal do “to” quase desaparece.",
    },
    {
      kind: "imagem",
      prompt: "They are shaking hands at the office.",
      pt: "Eles estão se cumprimentando com um aperto de mãos no escritório.",
      options: [
        {
          caption: "They are shaking hands at the office.",
          photo: "two people shaking hands in an office",
          src: "",
          credit: "",
        },
        {
          caption: "They are saying goodbye at the airport.",
          photo: "two people hugging goodbye at the airport",
          src: "",
          credit: "",
        },
        {
          caption: "They are having dinner together at home.",
          photo: "family having dinner together at home",
          src: "",
          credit: "",
        },
        {
          caption: "They are waiting for the bus on the street.",
          photo: "people waiting for the bus on the street",
          src: "",
          credit: "",
        },
      ],
      answer: 0,
      explanation:
        "O aperto de mãos é a saudação formal: as duas pessoas se cumprimentam de pé, não estão se despedindo nem comendo.",
    },
    {
      kind: "imagem",
      prompt: "She is waving goodbye at the airport.",
      pt: "Ela está se despedindo com a mão no aeroporto.",
      options: [
        {
          caption: "She is waving goodbye at the airport.",
          photo: "woman waving goodbye at the airport",
          src: "",
          credit: "",
        },
        {
          caption: "She is greeting a friend at the door.",
          photo: "woman greeting a friend at the door",
          src: "",
          credit: "",
        },
        {
          caption: "She is carrying her bags at the airport.",
          photo: "woman carrying bags at the airport",
          src: "",
          credit: "",
        },
        {
          caption: "She is checking in at the airport counter.",
          photo: "woman checking in at the airport counter",
          src: "",
          credit: "",
        },
      ],
      answer: 0,
      explanation:
        "A mão levantada e o aeroporto ao fundo dizem tudo: é uma despedida, com “bye” e não “hello”.",
    },
    {
      kind: "ouvirPalavra",
      audio: "goodbye",
      options: ["tchau", "bom dia", "até amanhã", "bem-vindo"],
      answer: 0,
      explanation:
        "“Goodbye” é a despedida completa. Na fala rápida vira só “bye” — mesma ideia, menos letras.",
    },
    {
      kind: "ouvirPalavra",
      audio: "good evening",
      options: ["boa noite (ao chegar)", "boa noite (ao sair)", "boa tarde", "bom dia"],
      answer: 0,
      explanation:
        "“Good evening” é o cumprimento da noite. Para se despedir à noite, use “good night”.",
    },
    {
      kind: "ouvirFrase",
      audio: "How are you today?",
      pt: "Como você está hoje?",
      options: [
        "How are you today?",
        "How old are you today?",
        "Where are you today?",
        "How are you feeling tonight?",
      ],
      answer: 0,
      explanation:
        "Ouça o fim da frase: “today”. As outras trocam o verbo, a pergunta de idade ou o horário.",
    },
    {
      kind: "ouvirFrase",
      audio: "Nice to see you again.",
      pt: "Que bom te ver de novo.",
      options: [
        "Nice to see you again.",
        "Nice to meet you, Ana.",
        "See you again tomorrow.",
        "Nice to be here again.",
      ],
      answer: 0,
      explanation:
        "“Nice to see you” é para quem você já conhece; “nice to meet you” só na primeira vez.",
    },
  ],
}
