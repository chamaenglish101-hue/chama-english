import type { LessonPracticeContent } from "#/lib/exercises.ts"

/** There is / there are — 12 perguntas. */
export const B12_PRACTICE: LessonPracticeContent = {
  id: "b12",
  level: "iniciante",
  exercises: [
    {
      kind: "completar",
      prompt: "___ a park near my house.",
      hint: "Há um parque perto da minha casa.",
      options: ["There is", "There are", "It is", "Have"],
      answer: 0,
      explanation:
        "Com uma coisa só, no singular, use “there is”. “There are” só com dois ou mais itens.",
    },
    {
      kind: "completar",
      prompt: "___ three bedrooms in the apartment.",
      hint: "Há três quartos no apartamento.",
      options: ["There are", "There is", "It has", "They are"],
      answer: 0,
      explanation:
        "“Three bedrooms” é plural, então o verbo vai para o plural: “there are”. O “there” aqui não é lugar.",
    },
    {
      kind: "traduzir",
      prompt: "Tem uma farmácia por aqui?",
      bank: ["Is", "there", "a", "pharmacy", "around", "here", "are"],
      answer: ["Is", "there", "a", "pharmacy", "around", "here"],
      explanation:
        "Na pergunta, o verbo vem antes: “is there…?”. A resposta curta pode ser “yes, there is”.",
    },
    {
      kind: "traduzir",
      prompt: "Há um banco ao lado da escola.",
      bank: ["There", "is", "a", "bank", "next", "to", "the", "school"],
      answer: ["There", "is", "a", "bank", "next", "to", "the", "school"],
      explanation:
        "“Next to” é ao lado de. A ordem em inglês é fixa: primeiro o que existe, depois onde fica.",
    },
    {
      kind: "falar",
      prompt: "There is a park near my house.",
      pt: "Há um parque perto da minha casa.",
      tip: "“There is” junta-se em “dér-iz”. A língua entre os dentes no “th”, e o “s” soa como “z”.",
    },
    {
      kind: "falar",
      prompt: "Is there a pharmacy around here?",
      pt: "Tem uma farmácia por aqui?",
      tip: "Em “pharmacy”, o “ph” soa como “f”: “FÁR-ma-si”. Na pergunta, a voz sobe no fim.",
    },
    {
      kind: "imagem",
      prompt: "There are two chairs at the table.",
      pt: "Há duas cadeiras na mesa.",
      options: [
        {
          caption: "There are two chairs at the table.",
          photo: "two chairs at a small table",
          src: "",
          credit: "",
        },
        {
          caption: "There is one chair at the table.",
          photo: "one chair at a small table",
          src: "",
          credit: "",
        },
        {
          caption: "There are four chairs at the table.",
          photo: "four chairs around a dining table",
          src: "",
          credit: "",
        },
        {
          caption: "There are two stools at the counter.",
          photo: "two stools at a kitchen counter",
          src: "",
          credit: "",
        },
      ],
      answer: 0,
      explanation:
        "Conte as cadeiras: são duas, com encosto, à mesa. Bancos altos não são cadeiras em inglês.",
    },
    {
      kind: "imagem",
      prompt: "There is a cat sleeping on the bed.",
      pt: "Há um gato dormindo na cama.",
      options: [
        {
          caption: "There is a cat sleeping on the bed.",
          photo: "one cat sleeping on a bed",
          src: "",
          credit: "",
        },
        {
          caption: "There is a dog sleeping on the sofa.",
          photo: "one dog sleeping on a sofa",
          src: "",
          credit: "",
        },
        {
          caption: "There are two cats sleeping on the bed.",
          photo: "two cats sleeping on a bed",
          src: "",
          credit: "",
        },
        {
          caption: "There is a cat sitting on the window.",
          photo: "one cat sitting on a windowsill",
          src: "",
          credit: "",
        },
      ],
      answer: 0,
      explanation:
        "Um animal, na cama: singular, “there is”. Trocar o animal ou o móvel muda a frase.",
    },
    {
      kind: "ouvirPalavra",
      audio: "around here",
      options: ["por aqui", "ali longe", "em casa", "na esquina"],
      answer: 0,
      explanation:
        "“Around here” é por aqui perto. Use no fim da pergunta: “is there a bank around here?”.",
    },
    {
      kind: "ouvirPalavra",
      audio: "next to",
      options: ["ao lado de", "em frente de", "atrás de", "dentro de"],
      answer: 0,
      explanation:
        "“Next to” é ao lado de. Em frente é “in front of” e atrás é “behind”.",
    },
    {
      kind: "ouvirFrase",
      audio: "There is a park near my house.",
      pt: "Há um parque perto da minha casa.",
      options: [
        "There is a park near my house.",
        "There are two parks near my house.",
        "There is a park near my office.",
        "There is a lake near my house.",
      ],
      answer: 0,
      explanation:
        "Ouça “is”, no singular, e a palavra “park”. As outras mudam o número, o lugar ou o cenário.",
    },
    {
      kind: "ouvirFrase",
      audio: "Are there any restaurants on this street?",
      pt: "Há algum restaurante nesta rua?",
      options: [
        "Are there any restaurants on this street?",
        "Is there any restaurant on this street?",
        "Are there any restaurants on that street?",
        "Are there any shops on this street?",
      ],
      answer: 0,
      explanation:
        "“Restaurants” está no plural, então o verbo é “are there”. E a rua é esta: “this street”.",
    },
  ],
}
