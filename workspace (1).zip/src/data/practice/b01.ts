import type { LessonPracticeContent } from "#/lib/exercises.ts"

/**
 * The twelve questions of lesson b01 — the reference lesson.
 *
 * Every other lesson follows this exact shape, so this file is the template a
 * reviewer reads first: same six kinds, same order, same amount of support text.
 */
export const B01_PRACTICE: LessonPracticeContent = {
  id: "b01",
  level: "iniciante",
  exercises: [
    {
      kind: "completar",
      prompt: "How do you ___ your name?",
      hint: "Como se escreve o seu nome?",
      options: ["spell", "say", "repeat", "listen"],
      answer: 0,
      explanation:
        "“Spell” é soletrar, letra por letra. “Say” é só falar — quem pergunta “how do you spell your name?” quer ouvir B-R-A-Z-I-L.",
    },
    {
      kind: "completar",
      prompt: "Sorry, I didn't catch that. Can you ___, please?",
      hint: "Desculpe, não entendi. Pode repetir, por favor?",
      options: ["repeat", "speak", "spell", "answer"],
      answer: 0,
      explanation:
        "“Can you repeat, please?” é o pedido de repetição mais usado. Vale decorar inteiro: resolve em qualquer conversa.",
    },
    {
      kind: "traduzir",
      prompt: "Olá, eu sou a Ana.",
      bank: ["Hello", "I", "am", "Ana", "You", "is"],
      answer: ["Hello", "I", "am", "Ana"],
      explanation:
        "O inglês sempre pede o sujeito: “I am”, nunca só “am”. E o nome vem no fim, como em português.",
    },
    {
      kind: "traduzir",
      prompt: "Eu sou do Brasil.",
      bank: ["I", "am", "from", "Brazil", "of", "the"],
      answer: ["I", "am", "from", "Brazil"],
      explanation:
        "Use “from” para origem: “I am from Brazil”. O “I” é sempre maiúsculo em inglês, mesmo no meio da frase.",
    },
    {
      kind: "falar",
      prompt: "How do you spell your name?",
      pt: "Como se escreve o seu nome?",
      tip: "Ligue as palavras: “how-dju” soa quase junto. E “spell” começa com /sp/, sem o “i” antes do s.",
    },
    {
      kind: "falar",
      prompt: "Sorry, I didn't catch that. Can you repeat, please?",
      pt: "Desculpe, não entendi. Pode repetir, por favor?",
      tip: "“Didn't” é curto: soa “dídnt”, com a língua batendo no céu da boca. Não separe em “did not”.",
    },
    {
      kind: "imagem",
      prompt: "They are spelling their names.",
      pt: "Eles estão soletrando os próprios nomes.",
      options: [
        {
          caption: "They are spelling their names.",
          photo: "two students writing letters in a notebook",
          src: "",
          credit: "",
        },
        {
          caption: "They are answering the phone at work.",
          photo: "woman answering the telephone at a desk",
          src: "",
          credit: "",
        },
        {
          caption: "They are looking at the whiteboard in class.",
          photo: "teacher pointing at the whiteboard in class",
          src: "",
          credit: "",
        },
        {
          caption: "They are talking on the phone with a friend.",
          photo: "woman talking on the phone smiling",
          src: "",
          credit: "",
        },
      ],
      answer: 0,
      explanation:
        "Soletrar é escrever letra por letra — por isso a cena é alguém com caderno e caneta, e não alguém falando ao telefone.",
    },
    {
      kind: "imagem",
      prompt: "She is listening to the English alphabet.",
      pt: "Ela está ouvindo o alfabeto em inglês.",
      options: [
        {
          caption: "She is listening to the English alphabet.",
          photo: "student with headphones listening at a desk",
          src: "",
          credit: "",
        },
        {
          caption: "She is writing a letter to a friend.",
          photo: "woman writing a letter with a pen at home",
          src: "",
          credit: "",
        },
        {
          caption: "She is speaking on the phone in English.",
          photo: "woman talking on the phone smiling",
          src: "",
          credit: "",
        },
        {
          caption: "She is reading a book on the sofa.",
          photo: "woman reading a book on the sofa",
          src: "",
          credit: "",
        },
      ],
      answer: 0,
      explanation:
        "O fone de ouvido é a pista: a lição é treinar o ouvido ouvindo os sons das letras.",
    },
    {
      kind: "ouvirPalavra",
      audio: "letter",
      options: ["letra", "número", "palavra", "língua"],
      answer: 0,
      explanation:
        "“Letter” é letra. Cuidado: “later” (mais tarde) soa parecido, mas tem outra vogal.",
    },
    {
      kind: "ouvirPalavra",
      audio: "to spell",
      options: ["soletrar", "repetir", "traduzir", "escrever"],
      answer: 0,
      explanation:
        "“To spell” é soletrar. “To write” é escrever o texto; soletrar é dizer cada letra em voz alta.",
    },
    {
      kind: "ouvirFrase",
      audio: "How do you spell your name?",
      pt: "Como se escreve o seu nome?",
      options: [
        "How do you spell your name?",
        "How do you write your name?",
        "What is your name?",
        "How do you say your name?",
      ],
      answer: 0,
      explanation:
        "A palavra-chave é “spell”. As outras frases falam de escrever, de saber o nome e de dizer — só uma pede a soletração.",
    },
    {
      kind: "ouvirFrase",
      audio: "Can you repeat, please?",
      pt: "Pode repetir, por favor?",
      options: [
        "Can you repeat, please?",
        "Can you speak, please?",
        "Can you read it, please?",
        "Can you spell it, please?",
      ],
      answer: 0,
      explanation:
        "“Repeat” aparece no meio da frase e puxa o acento. Ouça primeiro o “ri-PIIT” para escolher com segurança.",
    },
  ],
}
