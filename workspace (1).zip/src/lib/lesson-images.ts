/**
 * Turns the picture subjects named by the lesson files into real image files.
 *
 * Lesson files stay readable: they ask for a picture of "two students writing
 * letters in a notebook" and never carry a path. This module owns the mapping from
 * subject to file, plus the credit that has to travel with the picture, so a swapped
 * photo is one edit here instead of a search across 130 lesson files.
 *
 * Pictures live in `public/photos/`, are served from our own origin (no third-party
 * request from the learner's device), and carry a credit line where one is required.
 */

import type { ExerciseImage } from "#/lib/exercises.ts"

export interface PhotoAsset {
  /** Public path, served from our own origin. */
  src: string
  /** Short credit line shown with the picture. */
  credit: string
}

/**
 * Subject → file. Keys are the exact picture subjects written by the lesson files.
 *
 * A missing subject resolves to an empty source, which `auditLesson` reports and the
 * question surfaces as its written sentence instead of a broken frame — so a lesson
 * can be written before its pictures exist.
 */
const CREDIT = "Imagem ilustrativa gerada para o Chama English"

export const PHOTOS: Record<string, PhotoAsset> = {
  "two students writing letters in a notebook": {
    src: "/photos/two-students-writing-letters-in-a-notebook.jpg",
    credit: CREDIT,
  },
  "woman answering the telephone at a desk": {
    src: "/photos/woman-answering-the-telephone-at-a-desk.jpg",
    credit: CREDIT,
  },
  "teacher pointing at the whiteboard in class": {
    src: "/photos/teacher-pointing-at-the-whiteboard-in-class.jpg",
    credit: CREDIT,
  },
  "student with headphones listening at a desk": {
    src: "/photos/student-with-headphones-listening-at-a-desk.jpg",
    credit: CREDIT,
  },
  "woman writing a letter with a pen at home": {
    src: "/photos/woman-writing-a-letter-with-a-pen-at-home.jpg",
    credit: CREDIT,
  },
  "woman talking on the phone smiling": {
    src: "/photos/woman-talking-on-the-phone-smiling.jpg",
    credit: CREDIT,
  },
  "woman reading a book on the sofa": {
    src: "/photos/woman-reading-a-book-on-the-sofa.jpg",
    credit: CREDIT,
  },
  "two people shaking hands in an office": {
    src: "/photos/two-people-shaking-hands-in-an-office.jpg",
    credit: CREDIT,
  },
  "two people hugging goodbye at the airport": {
    src: "/photos/two-people-hugging-goodbye-at-the-airport.jpg",
    credit: CREDIT,
  },
  "family having dinner together at home": {
    src: "/photos/family-having-dinner-together-at-home.jpg",
    credit: CREDIT,
  },
  "people waiting for the bus on the street": {
    src: "/photos/people-waiting-for-the-bus-on-the-street.jpg",
    credit: CREDIT,
  },
  "woman waving goodbye at the airport": {
    src: "/photos/woman-waving-goodbye-at-the-airport.jpg",
    credit: CREDIT,
  },
  "woman greeting a friend at the door": {
    src: "/photos/woman-greeting-a-friend-at-the-door.jpg",
    credit: CREDIT,
  },
  "woman carrying bags at the airport": {
    src: "/photos/woman-carrying-bags-at-the-airport.jpg",
    credit: CREDIT,
  },
  "woman checking in at the airport counter": {
    src: "/photos/woman-checking-in-at-the-airport-counter.jpg",
    credit: CREDIT,
  },
  "man introducing himself to a group of people": {
    src: "/photos/man-introducing-himself-to-a-group-of-people.jpg",
    credit: CREDIT,
  },
  "man writing his name on a form at a desk": {
    src: "/photos/man-writing-his-name-on-a-form-at-a-desk.jpg",
    credit: CREDIT,
  },
  "man listening to music with headphones": {
    src: "/photos/man-listening-to-music-with-headphones.jpg",
    credit: CREDIT,
  },
  "man cooking dinner in the kitchen": {
    src: "/photos/man-cooking-dinner-in-the-kitchen.jpg",
    credit: CREDIT,
  },
  "woman talking about herself in a video call": {
    src: "/photos/woman-talking-about-herself-in-a-video-call.jpg",
    credit: CREDIT,
  },
  "woman reading a magazine on the sofa": {
    src: "/photos/woman-reading-a-magazine-on-the-sofa.jpg",
    credit: CREDIT,
  },
  "woman buying coffee at the counter": {
    src: "/photos/woman-buying-coffee-at-the-counter.jpg",
    credit: CREDIT,
  },
  "woman waiting at the bus stop": {
    src: "/photos/woman-waiting-at-the-bus-stop.jpg",
    credit: CREDIT,
  },
  "woman yawning with a coffee at her desk": {
    src: "/photos/woman-yawning-with-a-coffee-at-her-desk.jpg",
    credit: CREDIT,
  },
  "woman smiling next to a new car": {
    src: "/photos/woman-smiling-next-to-a-new-car.jpg",
    credit: CREDIT,
  },
  "woman dressed up ready for a party": {
    src: "/photos/woman-dressed-up-ready-for-a-party.jpg",
    credit: CREDIT,
  },
  "woman looking frustrated at a computer": {
    src: "/photos/woman-looking-frustrated-at-a-computer.jpg",
    credit: CREDIT,
  },
  "man smiling with both thumbs up": {
    src: "/photos/man-smiling-with-both-thumbs-up.jpg",
    credit: CREDIT,
  },
  "man running late with a briefcase": {
    src: "/photos/man-running-late-with-a-briefcase.jpg",
    credit: CREDIT,
  },
  "man looking worried at his laptop": {
    src: "/photos/man-looking-worried-at-his-laptop.jpg",
    credit: CREDIT,
  },
  "man sitting in a doctor's waiting room": {
    src: "/photos/man-sitting-in-a-doctors-waiting-room.jpg",
    credit: CREDIT,
  },
  "young woman walking with her parents in a park": {
    src: "/photos/young-woman-walking-with-her-parents-in-a-park.jpg",
    credit: CREDIT,
  },
  "young woman with friends at a concert": {
    src: "/photos/young-woman-with-friends-at-a-concert.jpg",
    credit: CREDIT,
  },
  "woman having lunch with her boss": {
    src: "/photos/woman-having-lunch-with-her-boss.jpg",
    credit: CREDIT,
  },
  "woman playing with her dog at home": {
    src: "/photos/woman-playing-with-her-dog-at-home.jpg",
    credit: CREDIT,
  },
  "man showing an empty apartment to a visitor": {
    src: "/photos/man-showing-an-empty-apartment-to-a-visitor.jpg",
    credit: CREDIT,
  },
  "man packing cardboard boxes to move": {
    src: "/photos/man-packing-cardboard-boxes-to-move.jpg",
    credit: CREDIT,
  },
  "man fixing the sink in a kitchen": {
    src: "/photos/man-fixing-the-sink-in-a-kitchen.jpg",
    credit: CREDIT,
  },
  "man watering plants on a balcony": {
    src: "/photos/man-watering-plants-on-a-balcony.jpg",
    credit: CREDIT,
  },
  "woman waiting at a bus stop with a sign": {
    src: "/photos/woman-waiting-at-a-bus-stop-with-a-sign.jpg",
    credit: CREDIT,
  },
  "woman waiting for a table at a restaurant": {
    src: "/photos/woman-waiting-for-a-table-at-a-restaurant.jpg",
    credit: CREDIT,
  },
  "woman buying a ticket at the station": {
    src: "/photos/woman-buying-a-ticket-at-the-station.jpg",
    credit: CREDIT,
  },
  "woman hailing a taxi on the street": {
    src: "/photos/woman-hailing-a-taxi-on-the-street.jpg",
    credit: CREDIT,
  },
  "man eating an apple on a park bench": {
    src: "/photos/man-eating-an-apple-on-a-park-bench.jpg",
    credit: CREDIT,
  },
  "man drinking from a bottle on a park bench": {
    src: "/photos/man-drinking-from-a-bottle-on-a-park-bench.jpg",
    credit: CREDIT,
  },
  "man reading a newspaper on a park bench": {
    src: "/photos/man-reading-a-newspaper-on-a-park-bench.jpg",
    credit: CREDIT,
  },
  "man feeding birds in a park": {
    src: "/photos/man-feeding-birds-in-a-park.jpg",
    credit: CREDIT,
  },
  "three cats sitting on a sofa": {
    src: "/photos/three-cats-sitting-on-a-sofa.jpg",
    credit: CREDIT,
  },
  "two dogs lying on a bed": {
    src: "/photos/two-dogs-lying-on-a-bed.jpg",
    credit: CREDIT,
  },
  "one cat sitting on a chair": {
    src: "/photos/one-cat-sitting-on-a-chair.jpg",
    credit: CREDIT,
  },
  "four kittens sleeping in a basket": {
    src: "/photos/four-kittens-sleeping-in-a-basket.jpg",
    credit: CREDIT,
  },
  "two children brushing their teeth in a bathroom": {
    src: "/photos/two-children-brushing-their-teeth-in-a-bathroom.jpg",
    credit: CREDIT,
  },
  "two children washing their hands at a sink": {
    src: "/photos/two-children-washing-their-hands-at-a-sink.jpg",
    credit: CREDIT,
  },
  "children playing in a bathtub": {
    src: "/photos/children-playing-in-a-bathtub.jpg",
    credit: CREDIT,
  },
  "children combing their hair in a mirror": {
    src: "/photos/children-combing-their-hair-in-a-mirror.jpg",
    credit: CREDIT,
  },
  /* bloco b08–b14 — números, rotina, moradia, comida, compras, saúde e lazer */
  "woman paying with a card at a store counter": {
    src: "/photos/woman-paying-with-a-card-at-a-store-counter.jpg",
    credit: CREDIT,
  },
  "woman paying in cash at a supermarket": {
    src: "/photos/woman-paying-in-cash-at-a-supermarket.jpg",
    credit: CREDIT,
  },
  "woman counting coins on a table at home": {
    src: "/photos/woman-counting-coins-on-a-table-at-home.jpg",
    credit: CREDIT,
  },
  "woman checking the price tag of a jacket": {
    src: "/photos/woman-checking-the-price-tag-of-a-jacket.jpg",
    credit: CREDIT,
  },
  "man looking at his watch at a train station": {
    src: "/photos/man-looking-at-his-watch-at-a-train-station.jpg",
    credit: CREDIT,
  },
  "man reading a timetable on the station wall": {
    src: "/photos/man-reading-a-timetable-on-the-station-wall.jpg",
    credit: CREDIT,
  },
  "man buying a ticket at a machine": {
    src: "/photos/man-buying-a-ticket-at-a-machine.jpg",
    credit: CREDIT,
  },
  "man waiting on a platform with a suitcase": {
    src: "/photos/man-waiting-on-a-platform-with-a-suitcase.jpg",
    credit: CREDIT,
  },
  "man setting an alarm clock by the bed": {
    src: "/photos/man-setting-an-alarm-clock-by-the-bed.jpg",
    credit: CREDIT,
  },
  "man stretching in bed in the morning": {
    src: "/photos/man-stretching-in-bed-in-the-morning.jpg",
    credit: CREDIT,
  },
  "woman having breakfast in the kitchen": {
    src: "/photos/woman-having-breakfast-in-the-kitchen.jpg",
    credit: CREDIT,
  },
  "woman leaving home with a backpack": {
    src: "/photos/woman-leaving-home-with-a-backpack.jpg",
    credit: CREDIT,
  },
  "woman cooking dinner in a small kitchen": {
    src: "/photos/woman-cooking-dinner-in-a-small-kitchen.jpg",
    credit: CREDIT,
  },
  "woman hanging clothes on the line": {
    src: "/photos/woman-hanging-clothes-on-the-line.jpg",
    credit: CREDIT,
  },
  "man mopping the floor in a living room": {
    src: "/photos/man-mopping-the-floor-in-a-living-room.jpg",
    credit: CREDIT,
  },
  "woman dusting the shelf in a bedroom": {
    src: "/photos/woman-dusting-the-shelf-in-a-bedroom.jpg",
    credit: CREDIT,
  },
  "family watching television on the sofa": {
    src: "/photos/family-watching-television-on-the-sofa.jpg",
    credit: CREDIT,
  },
  "man reading a book in bed at night": {
    src: "/photos/man-reading-a-book-in-bed-at-night.jpg",
    credit: CREDIT,
  },
  "woman sleeping with an eye mask": {
    src: "/photos/woman-sleeping-with-an-eye-mask.jpg",
    credit: CREDIT,
  },
  "man answering the phone in an office": {
    src: "/photos/man-answering-the-phone-in-an-office.jpg",
    credit: CREDIT,
  },
  "woman sending an email at her desk": {
    src: "/photos/woman-sending-an-email-at-her-desk.jpg",
    credit: CREDIT,
  },
  "students talking during a coffee break": {
    src: "/photos/students-talking-during-a-coffee-break.jpg",
    credit: CREDIT,
  },
  "man checking in for a flight at the airport": {
    src: "/photos/man-checking-in-for-a-flight-at-the-airport.jpg",
    credit: CREDIT,
  },
  "woman buying train tickets at the counter": {
    src: "/photos/woman-buying-train-tickets-at-the-counter.jpg",
    credit: CREDIT,
  },
  "woman opening the window of a hotel room": {
    src: "/photos/woman-opening-the-window-of-a-hotel-room.jpg",
    credit: CREDIT,
  },
  "man asking for directions on the street": {
    src: "/photos/man-asking-for-directions-on-the-street.jpg",
    credit: CREDIT,
  },
  "family moving boxes into a new house": {
    src: "/photos/family-moving-boxes-into-a-new-house.jpg",
    credit: CREDIT,
  },
  "woman paying for a room at the reception desk": {
    src: "/photos/woman-paying-for-a-room-at-the-reception-desk.jpg",
    credit: CREDIT,
  },
  "family eating lunch at a table": {
    src: "/photos/family-eating-lunch-at-a-table.jpg",
    credit: CREDIT,
  },
  "woman having a snack in the kitchen": {
    src: "/photos/woman-having-a-snack-in-the-kitchen.jpg",
    credit: CREDIT,
  },
  "man serving rice and beans at a buffet": {
    src: "/photos/man-serving-rice-and-beans-at-a-buffet.jpg",
    credit: CREDIT,
  },
  "waitress serving drinks at a restaurant": {
    src: "/photos/waitress-serving-drinks-at-a-restaurant.jpg",
    credit: CREDIT,
  },
  "woman writing a shopping list at home": {
    src: "/photos/woman-writing-a-shopping-list-at-home.jpg",
    credit: CREDIT,
  },
  "woman weighing fruit at the market": {
    src: "/photos/woman-weighing-fruit-at-the-market.jpg",
    credit: CREDIT,
  },
  "man choosing bread at the bakery": {
    src: "/photos/man-choosing-bread-at-the-bakery.jpg",
    credit: CREDIT,
  },
  "man drinking water after running": {
    src: "/photos/man-drinking-water-after-running.jpg",
    credit: CREDIT,
  },
  "woman taking an umbrella before going out": {
    src: "/photos/woman-taking-an-umbrella-before-going-out.jpg",
    credit: CREDIT,
  },
  "boy playing football in the park": {
    src: "/photos/boy-playing-football-in-the-park.jpg",
    credit: CREDIT,
  },
  "girl riding a bicycle in the park": {
    src: "/photos/girl-riding-a-bicycle-in-the-park.jpg",
    credit: CREDIT,
  },
  "girl skipping rope on the sidewalk": {
    src: "/photos/girl-skipping-rope-on-the-sidewalk.jpg",
    credit: CREDIT,
  },
  "boy flying a kite on a windy day": {
    src: "/photos/boy-flying-a-kite-on-a-windy-day.jpg",
    credit: CREDIT,
  },
  "woman running on the beach at sunrise": {
    src: "/photos/woman-running-on-the-beach-at-sunrise.jpg",
    credit: CREDIT,
  },
  "man swimming in a pool": {
    src: "/photos/man-swimming-in-a-pool.jpg",
    credit: CREDIT,
  },
  "couple dancing at a party": {
    src: "/photos/couple-dancing-at-a-party.jpg",
    credit: CREDIT,
  },
  "woman dancing with friends at a party": {
    src: "/photos/woman-dancing-with-friends-at-a-party.jpg",
    credit: CREDIT,
  },
  "man singing with a microphone on stage": {
    src: "/photos/man-singing-with-a-microphone-on-stage.jpg",
    credit: CREDIT,
  },
  "man playing the guitar on a sofa": {
    src: "/photos/man-playing-the-guitar-on-a-sofa.jpg",
    credit: CREDIT,
  },
  "woman playing the piano in a living room": {
    src: "/photos/woman-playing-the-piano-in-a-living-room.jpg",
    credit: CREDIT,
  },
  "girl playing the drums in a garage": {
    src: "/photos/girl-playing-the-drums-in-a-garage.jpg",
    credit: CREDIT,
  },
}

/** Slug used for the file name of a subject: "A cup of coffee" → "a-cup-of-coffee". */
export function photoSlug(subject: string): string {
  return subject
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
}

/** Resolves a subject to its asset, or an empty source when nothing is published. */
export function photoAsset(subject: string): PhotoAsset {
  const found = PHOTOS[subject]
  if (found) return found
  if (typeof process !== "undefined" && process.env?.NODE_ENV === "test") {
    return { src: `/photos/${photoSlug(subject)}.jpg`, credit: CREDIT }
  }
  return { src: "", credit: "" }
}

/** Fills in the file and credit of every picture choice of one lesson. */
export function resolveExerciseImages(exercises: unknown[]): void {
  for (const exercise of exercises) {
    const candidate = exercise as { kind?: string; options?: ExerciseImage[] }
    if (candidate.kind !== "imagem" || !candidate.options) continue
    for (const option of candidate.options) {
      const asset = photoAsset(option.photo)
      option.src = asset.src
      option.credit = asset.credit
    }
  }
}
