/**
 * Spoken audio, produced by the device itself.
 *
 * The lessons need an English voice for roughly 1.500 sentences without shipping
 * 1.500 audio files. The browser already has one: `speechSynthesis` speaks any text
 * with an `en-US` voice, works offline, costs nothing, and keeps a lesson fix and
 * its audio in the same edit. Where the browser has no English voice the screens
 * fall back to showing the sentence, so nothing breaks — the learner just reads
 * instead of listens.
 */

const ENGLISH = "en-US"

interface SpeakOptions {
  /** 1 is normal speed; 0.85 is used for teaching, where clarity beats pace. */
  rate?: number
  /** Called once the utterance ends, is cancelled, or fails. */
  onEnd?: () => void
}

function supported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window
}

/** Picks an English voice when the device has one installed. */
function englishVoice(): SpeechSynthesisVoice | null {
  const voices = window.speechSynthesis.getVoices()
  if (!voices.length) return null
  return (
    voices.find((voice) => voice.lang === ENGLISH) ??
    voices.find((voice) => voice.lang?.startsWith("en")) ??
    null
  )
}

/**
 * Speaks one piece of English text.
 *
 * Calls cancel first: without it, tapping "Ouvir" twice queues the sentence and the
 * learner hears it twice over. Returns whether the device could actually speak, so
 * the caller can offer a visible fallback instead of a silent button.
 */
export function speakEnglish(text: string, options: SpeakOptions = {}): boolean {
  if (!supported() || !text.trim()) {
    options.onEnd?.()
    return false
  }

  try {
    const synth = window.speechSynthesis
    synth.cancel()

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = ENGLISH
    utterance.rate = options.rate ?? 0.9
    utterance.pitch = 1

    const voice = englishVoice()
    if (voice) utterance.voice = voice

    let finished = false
    const finish = () => {
      if (finished) return
      finished = true
      options.onEnd?.()
    }
    utterance.onend = finish
    utterance.onerror = finish

    synth.speak(utterance)
    return true
  } catch {
    options.onEnd?.()
    return false
  }
}

/** Stops whatever is being spoken — used when leaving a question. */
export function stopSpeaking(): void {
  if (!supported()) return
  try {
    window.speechSynthesis.cancel()
  } catch {
    /* nothing to stop */
  }
}

/* --------------------------------------------- pronunciation self-assessment */

export interface TranscriptMatch {
  /** 0–1: how much of the target sentence the learner actually said. */
  score: number
  /** The target word that was missed first, for a specific, actionable hint. */
  missed: string | null
  /** True when every target word was heard. */
  perfect: boolean
}

const FILLERS = new Set([
  "a",
  "an",
  "the",
  "to",
  "of",
  "is",
  "am",
  "are",
  "do",
  "does",
  "did",
  "you",
  "i",
  "we",
  "it",
  "'s",
  "s",
])

/** Normalises a word for comparison: lowercase, no punctuation, no accents. */
function normaliseWord(word: string): string {
  return word
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9']/g, "")
}

function words(text: string): string[] {
  return text
    .split(/\s+/)
    .map(normaliseWord)
    .filter(Boolean)
}

/**
 * Two words match when they are equal, or when one is the other plus a plural or
 * verb ending. Recognition engines drop endings all the time — "wants" comes back
 * as "want" — and failing a learner for that would be dishonest, not strict.
 */
function sameWord(target: string, said: string): boolean {
  if (target === said) return true
  if (!target || !said) return false
  const trim = (word: string, endings: string[]) => {
    for (const ending of endings) {
      if (word.endsWith(ending) && word.length - ending.length >= 3) {
        return word.slice(0, word.length - ending.length)
      }
    }
    return word
  }
  const endings = ["s", "es", "ed", "ing", "'s", "d"]
  return trim(target, endings) === trim(said, endings)
}

/**
 * Compares what the microphone heard with the sentence the lesson asked for.
 *
 * The engine's own confidence score is ignored on purpose: it varies wildly between
 * devices and would pass or fail the same pronunciation on two phones. Word overlap
 * is stable, explainable, and can point at the exact word to practise.
 *
 * Ordinary connecting words are forgiven — a learner who says "I like coffee" for
 * "I'd like a coffee" understood the sentence. Content words are not: those are what
 * the lesson is teaching.
 */
export function matchTranscript(target: string, heard: string): TranscriptMatch {
  const targetWords = words(target)
  const heardWords = words(heard)

  if (!targetWords.length) return { score: 0, missed: null, perfect: false }
  if (!heardWords.length) {
    return { score: 0, missed: targetWords[0], perfect: false }
  }

  const remaining = [...heardWords]
  const results = targetWords.map((word) => {
    const index = remaining.findIndex((candidate) => sameWord(word, candidate))
    if (index >= 0) {
      remaining.splice(index, 1)
      return { word, hit: true }
    }
    return { word, hit: false }
  })

  const misses = results.filter((result) => !result.hit)
  const scored = results.filter((result) => !FILLERS.has(result.word))
  const scoredHits = scored.filter((result) => result.hit)

  // A sentence made only of connecting words still has to be measured somehow.
  const total = scored.length || results.length
  const hits = scored.length ? scoredHits.length : results.length - misses.length
  // A skipped connecting word is forgiven: a recogniser that drops an unstressed "of"
  // is reporting its own limits, not the learner's pronunciation.
  const score = total ? hits / total : 0

  // Measured again with every word counted. The difference between the two scores is
  // what the forgiveness actually bought, and that is what gets capped: forgiving a
  // dropped unstressed word is fine, letting it carry half a sentence is not.
  const rawTotal = results.length
  const rawScore = rawTotal ? (rawTotal - misses.length) / rawTotal : 0
  const borrowed = score - rawScore
  const forgivenessBudget = Math.max(score - Math.max(rawScore, 0.6), 0)
  const capped = Math.min(score, rawScore + Math.min(borrowed, forgivenessBudget, 0.2))

  const contentMisses = misses.filter((result) => !FILLERS.has(result.word))
  const firstMiss = contentMisses[0] ?? misses[0] ?? null

  return {
    score: capped,
    missed: firstMiss ? firstMiss.word : null,
    perfect: misses.length === 0,
  }
}

/** How a score reads on screen. */
export function scoreVerdict(score: number): "great" | "close" | "retry" {
  if (score >= 0.85) return "great"
  if (score >= 0.5) return "close"
  return "retry"
}

/* --------------------------------------------- microphone and speech input */

type RecognitionResult = {
  results: ArrayLike<ArrayLike<{ transcript: string }>>
}

interface Recognition {
  lang: string
  interimResults: boolean
  maxAlternatives: number
  continuous: boolean
  start: () => void
  stop: () => void
  abort: () => void
  onresult: ((event: RecognitionResult) => void) | null
  onerror: ((event: { error: string }) => void) | null
  onend: (() => void) | null
}

type RecognitionConstructor = new () => Recognition

function recognitionConstructor(): RecognitionConstructor | null {
  if (typeof window === "undefined") return null
  const scope = window as unknown as {
    SpeechRecognition?: RecognitionConstructor
    webkitSpeechRecognition?: RecognitionConstructor
  }
  return scope.SpeechRecognition ?? scope.webkitSpeechRecognition ?? null
}

/** Whether this device can listen at all. */
export function speechInputSupported(): boolean {
  return recognitionConstructor() !== null
}

export interface ListenOptions {
  /** Called with the best transcript once the learner stops talking. */
  onResult: (transcript: string) => void
  /** Called with a readable Portuguese explanation when nothing arrived. */
  onError: (reason: "denied" | "unsupported" | "no-speech" | "failed") => void
  /** Longest the microphone stays open, in ms. */
  timeoutMs?: number
}

export interface Listening {
  stop: () => void
  abort: () => void
}

/**
 * Opens the microphone for one sentence.
 *
 * Listening is always started by a tap and always ends on silence or on the timeout,
 * because a microphone that stays open without a visible record is exactly the kind
 * of surprise a learner should never get. Every exit path reports exactly once, so
 * the caller can always show "tente de novo" instead of a spinner that never stops.
 */
export function listenOnce(options: ListenOptions): Listening | null {
  const Constructor = recognitionConstructor()
  if (!Constructor) {
    options.onError("unsupported")
    return null
  }

  let settled = false
  const finish = (run: () => void) => {
    if (settled) return
    settled = true
    window.clearTimeout(timeout)
    run()
  }

  const recognition = new Constructor()
  recognition.lang = ENGLISH
  recognition.interimResults = false
  recognition.continuous = false
  recognition.maxAlternatives = 1

  const timeout = window.setTimeout(() => {
    finish(() => {
      try {
        recognition.stop()
      } catch {
        /* already closed */
      }
      options.onError("no-speech")
    })
  }, options.timeoutMs ?? 8000)

  recognition.onresult = (event) => {
    const first = event.results?.[0]?.[0]
    const transcript = first?.transcript?.trim() ?? ""
    if (!transcript) {
      finish(() => options.onError("no-speech"))
      return
    }
    finish(() => options.onResult(transcript))
  }

  recognition.onerror = (event) => {
    const denied = event.error === "not-allowed" || event.error === "service-not-allowed"
    const silent = event.error === "no-speech" || event.error === "aborted"
    finish(() =>
      options.onError(denied ? "denied" : silent ? "no-speech" : "failed"),
    )
  }

  // Some browsers end the session without a result; that must not hang the screen.
  recognition.onend = () => finish(() => options.onError("no-speech"))

  try {
    recognition.start()
  } catch {
    finish(() => options.onError("failed"))
    return null
  }

  return {
    stop: () => {
      try {
        recognition.stop()
      } catch {
        /* already closed */
      }
    },
    abort: () => {
      settled = true
      window.clearTimeout(timeout)
      try {
        recognition.abort()
      } catch {
        /* already closed */
      }
    },
  }
}

/** Portuguese messages for every way listening can fail. */
export const LISTEN_ERRORS: Record<
  "denied" | "unsupported" | "no-speech" | "failed",
  string
> = {
  denied:
    "O navegador não deixou usar o microfone. Você pode liberar nas permissões do site ou pular esta pergunta.",
  unsupported:
    "Este navegador não ouve pelo microfone. Pule esta pergunta: o resto da lição funciona normalmente.",
  "no-speech":
    "Não ouvimos nada. Aproxime-se do microfone e tente de novo, ou pule esta pergunta.",
  failed: "Algo deu errado ao ouvir. Tente de novo ou pule esta pergunta.",
}
