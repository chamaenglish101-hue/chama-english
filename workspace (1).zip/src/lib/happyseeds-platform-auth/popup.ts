const AUTH_COMPLETE_MESSAGE = "happyseeds:auth-complete"
const DEFAULT_TIMEOUT_MS = 120_000

export interface HappySeedsLoginCallbacks {
  onComplete: () => void
  onClosed: () => void
  onTimeout: () => void
  timeoutMs?: number
}

export function normalizeHappySeedsNext(value: string | null | undefined): string {
  if (!value?.startsWith("/") || value.startsWith("//") || value.includes("\\"))
    return "/"
  try {
    const base = new URL("https://happyseeds.invalid")
    const destination = new URL(value, base)
    if (destination.origin !== base.origin) return "/"
    return `${destination.pathname}${destination.search}${destination.hash}`
  } catch {
    return "/"
  }
}

/**
 * Opens the same-origin login route in a popup.
 *
 * Must be called synchronously from a real click: Google OAuth may not render
 * inside the HappySeeds preview iframe, and a popup opened outside a user
 * gesture is blocked. A `null` return means blocked — fall back to a
 * `target="_blank"` link to `/api/auth/login`.
 *
 * Every terminal callback must leave the UI's loading state. Completion and
 * closure are only refresh signals; authentication is proven when the root
 * route context reloads the verified session.
 */
export function openHappySeedsLogin(
  callbacks: HappySeedsLoginCallbacks,
  next = "/",
): Window | null {
  const width = 500
  const height = 650
  const left = Math.max(
    0,
    Math.round(window.screenX + (window.outerWidth - width) / 2),
  )
  const top = Math.max(
    0,
    Math.round(window.screenY + (window.outerHeight - height) / 2),
  )
  const popup = window.open(
    `/api/auth/login?next=${encodeURIComponent(normalizeHappySeedsNext(next))}`,
    `happyseeds_auth_${crypto.randomUUID()}`,
    `popup=yes,width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes`,
  )
  if (!popup) return null

  let settled = false
  let closedCheck: number | undefined
  let timeout: number | undefined

  function finish(callback: () => void): void {
    if (settled) return
    settled = true
    if (closedCheck !== undefined) window.clearInterval(closedCheck)
    if (timeout !== undefined) window.clearTimeout(timeout)
    window.removeEventListener("message", receiveCompletion)
    callback()
  }

  function receiveCompletion(event: MessageEvent): void {
    if (
      event.origin !== window.location.origin ||
      event.source !== popup ||
      event.data?.type !== AUTH_COMPLETE_MESSAGE
    ) {
      return
    }
    finish(callbacks.onComplete)
  }

  window.addEventListener("message", receiveCompletion)
  closedCheck = window.setInterval(() => {
    try {
      if (!popup.closed) return
      finish(callbacks.onClosed)
    } catch {
      // Cross-Origin-Opener-Policy can make the popup handle unreadable. The timeout still terminates the wait.
    }
  }, 500)
  timeout = window.setTimeout(
    () => finish(callbacks.onTimeout),
    callbacks.timeoutMs ?? DEFAULT_TIMEOUT_MS,
  )
  return popup
}
