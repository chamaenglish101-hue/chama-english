/**
 * Runs the practice content through its integrity checks and prints every problem.
 *
 *   pnpm practice:audit
 *
 * The questions are hand-written across 130 lessons, so the likely mistake is a
 * mistyped answer index or a picture that was never published — not a crash. This
 * prints all of them at once, so a lesson can be checked while it is being written.
 */

import { PRACTICE_LESSONS } from "../src/data/practice/index.ts"
import { auditLesson } from "../src/lib/exercises.ts"
import { resolveExerciseImages } from "../src/lib/lesson-images.ts"
import { CATALOG } from "../src/data/catalog.ts"

const published = new Set(PRACTICE_LESSONS.map((lesson) => lesson.id))
let problems = 0

for (const lesson of PRACTICE_LESSONS) {
  const copy = structuredClone(lesson)
  resolveExerciseImages(copy.exercises)
  const found = auditLesson(copy)
  if (found.length === 0) {
    console.log(`ok   ${lesson.id} — 12 perguntas`)
    continue
  }
  problems += found.length
  console.log(`ERRO ${lesson.id}`)
  for (const problem of found) console.log(`       ${problem}`)
}

const missing = CATALOG.filter((lesson) => !published.has(lesson.id)).length
console.log(
  `\n${PRACTICE_LESSONS.length} lições publicadas · ${missing} ainda por escrever · ${problems} problemas`,
)

if (problems > 0) process.exitCode = 1
